#ifndef GOALIE_LMS
#define GOALIE_LMS

#include "utils/PlayerTask.h"
#include "utils/maths.h"
#include "utils/worldmodel.h"

//extern "C"_declspec(dllexport) PlayerTask player_plan(const WorldModel* model, int robot_id);
//bool is_inside_penalty(const point2f& p);




#endif